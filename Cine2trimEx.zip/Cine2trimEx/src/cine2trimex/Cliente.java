/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;
import java.util.ArrayList;


/**
 *
 * @author win_a
 */
// Interfaz Imprimible
    
    
public class Cliente extends Persona implements Imprimible {

    static ArrayList<Cliente> getclientes;
    private int codCliente;
    private float descuento;
    private ArrayList<Venta> clientes;
    private ArrayList<Persona> dni;
    private ArrayList<Persona> sexo;
    private ArrayList<Persona> email;
    private ArrayList<Persona> nombre;
    private ArrayList<Persona> localidadPertence;
    private ArrayList<Cliente> cli1;  // Cola de la taquilla 1
    private ArrayList<Cliente> cli2;  // Cola de la taquilla 2
    
    
    
    @Override
    public String toString() {
        return "Cliente{" +
                "dni='" + dni + '\'' +
                ", sexo=" + sexo +
                ", email='" + email + '\'' +
                ", nombre='" + nombre + '\'' +
                ", codCliente=" + codCliente +
                ", descuento=" + descuento +
                ", localidad=" + localidadPertence+
                '}';
    }
    
    
  

    // Constructor
    public Cliente(String dni, char sexo, String email, String nombre, Localidad localidad) {
        super(dni, sexo, email, nombre, localidad);
        this.codCliente = codCliente;
        this.descuento = descuento;
        this.clientes = new ArrayList<>();
        this.cli1 = new ArrayList<>();  // Cola de la taquilla 1
        this.cli2 = new ArrayList<>();  // Cola de la taquilla 2
    }

     // Constructor y otros métodos
    public void realizarCompra(Venta compra) {
        clientes.add(compra);
        System.out.println("Compra realizada por " + getNombre() + ". Número de venta: " + compra.getNumVenta());
    }

    @Override
    public void imprimirInformacion() {
        System.out.println("Información del Cliente: " + getNombre() + ", Descuento: " + descuento);
        
        if (!clientes.isEmpty()) {
            System.out.println("Ventas realizadas por " + getNombre() + ":");
            for (Venta venta : clientes) {
                System.out.println("Número de venta: " + venta.getNumVenta() + ", Cantidad: " + venta.getCantidad());
            }
        } else {
            System.out.println("Este cliente no ha realizado ninguna compra.");
        }
    }
    
    // Getter para codCliente
    public int getCodClientes() {
        return codCliente;
    }

    // Setter para codCliente
    public void setCodClientes(int codCliente) {
        this.codCliente = codCliente;
    }
    
    // Getter y Setter para cli1
    public ArrayList<Cliente> getCli1() {
        return cli1;
    }

    public void setCli1(ArrayList<Cliente> cli1) {
        this.cli1 = cli1;
    }

    // Getter y Setter para cli2
    public ArrayList<Cliente> getCli2() {
        return cli2;
    }

    public void setCli2(ArrayList<Cliente> cli2) {
        this.cli2 = cli2;
    }

    // Getter para descuento
    public float getDescuento() {
        return descuento;
    }

    // Setter para descuento
    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }

    // Método adicional para aumentar el descuento
    public void aumentarDescuento() {
        // Lógica para aumentar el descuento (por ejemplo, cada entrada comprada aumenta un 0.1%)
        this.descuento += 0.1;
    }

    Object getCodCliente() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

