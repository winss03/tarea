/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cine2trimex;

/**
 *
 * @author win_a
 */
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Cine2trimEx {
    // Variables globales
    static double numHombres;
    static double numMujeres;
    

    
    // Variables locales
    static List<Empleado> empleados = new ArrayList<>();
    static List<Taquilla> taquillas = new ArrayList<>();
    static List<Localidad> localidades = new ArrayList<>();
    static List<Cliente> clientes = new ArrayList<>();
    static ArrayList<Venta> ventas = new ArrayList<>();
    static List<Pelicula> peliculas = new ArrayList<>();
    static List<Entrada> entradas = new ArrayList<>();
    static List<Empleado> nick = new ArrayList<>();
    private static Localidad murcia;
    private static Localidad molina;
    
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Agregar empleados
        Empleado empT1 = new Empleado("js", 'M', "js@gmail.com", "Juan Salvador", "nick1", 1, murcia);
        Empleado empT2 = new Empleado("mg", 'F', "mg@gmail.com", "María García", "nick2", 2, molina);
        empleados.add(empT1);
        empleados.add(empT2);

        // Agregar taquillas
        Taquilla t1 = new Taquilla(1, 20);
        Taquilla t2 = new Taquilla(2, 20);
        Taquilla t3 = new Taquilla(3, 20);
        t1.asignarEmpleado(empT1);
        t2.asignarEmpleado(empT2);
        taquillas.add(t1);
        taquillas.add(t2);
        taquillas.add(t3);

        // Agregar localidades
        Localidad murcia = new Localidad(30008, "Murcia", 300000);
        Localidad molina = new Localidad(30500, "Molina de Segura", 70000);
        localidades.add(murcia);
        localidades.add(molina);

        // Agregar clientes
        Cliente hombre = new Cliente("11111111A", 'M', "abcd@gmail.com", "Juan", murcia);
        Cliente mujer = new Cliente("22222222B", 'F', "qwerty@gmail.com", "María", molina);
        clientes.add(hombre);
        clientes.add(mujer);

        // Agregar películas
        Pelicula p1 = new Pelicula(1, 240, "Avatar 1", "Ciencia Ficción");
        Pelicula p2 = new Pelicula(2, 100, "La Cenicienta", "Infantil");
        Pelicula p3 = new Pelicula(3, 90, "Smile", "Terror");
        peliculas.add(p1);
        peliculas.add(p2);
        peliculas.add(p3);

        // Agregar entradas
        Entrada mañana1 = new Entrada(1, new GregorianCalendar(2023, Calendar.JUNE, 6, 12, 0), 10.0f, p1);
        Entrada mañana2 = new Entrada(2, new GregorianCalendar(2023, Calendar.JUNE, 6, 12, 30), 10.0f, p2);
        Entrada mañana3 = new Entrada(3, new GregorianCalendar(2023, Calendar.JUNE, 6, 13, 0), 10.0f, p3);
        Entrada tarde1 = new Entrada(4, new GregorianCalendar(2023, Calendar.JUNE, 6, 18, 0), 12.0f, p1);
        Entrada tarde2 = new Entrada(5, new GregorianCalendar(2023, Calendar.JUNE, 6, 18, 30), 12.0f, p2);
        Entrada tarde3 = new Entrada(6, new GregorianCalendar(2023, Calendar.JUNE, 6, 19, 0), 12.0f, p3);

        entradas.add(mañana1);
        entradas.add(mañana2);
        entradas.add(mañana3);
        entradas.add(tarde1);
        entradas.add(tarde2);
        entradas.add(tarde3);

        // Realizar ventas
        t1.meterPersonaEnCola(hombre);
        t2.meterPersonaEnCola(mujer);
        

        // Crear un cine con 3 taquillas, cada una con capacidad máxima de 5 personas
        Cine cine = new Cine(1, 3, 20);

        int opcion;
        do {
            System.out.println("\nMenú:");
            System.out.println("1. Meter a una persona en la cola");
            System.out.println("2. Atender a una persona");
            System.out.println("3. Estadísticas por sexos");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Lógica para añadir persona a la cola
                    meterEnCola(taquillas, clientes);
                    break;
                    
                case 2:
                    // Lógica para atender persona
                    atenderPersona(taquillas, clientes, ventas);
                    break;

                case 3:
                    // Lógica para mostrar estadísticas
                    cine.mostrarEstadisticas();
                    estadistica(ventas, (ArrayList<Cliente>) clientes);
                    break;
                case 0:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    // Opción no válida, mostrar mensaje de advertencia
                    JOptionPane.showMessageDialog(null, "Opción incorrecta", "Atención", JOptionPane.WARNING_MESSAGE);
                     break;

                
                
            }

        } while (opcion != 0);
        System.out.println("Ha ocurrido un problema");
        
        
    }   
        
    

    
     /*// Método para crear un nuevo Cliente desde la entrada del usuario
    private static Cliente crearClienteDesdeEntrada() {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Ingrese el DNI del cliente: ");
    String dni = scanner.nextLine();

    System.out.print("Ingrese el nombre del cliente: ");
    String nombre = scanner.nextLine();

    System.out.print("Ingrese el sexo del cliente (M/F): ");
    char sexo = scanner.next().charAt(0);

    // Consumir el salto de línea pendiente
    scanner.nextLine();

    System.out.print("Ingrese el email del cliente: ");
    String email = scanner.nextLine();

    System.out.print("Ingrese el código postal del cliente: ");
    String cp = scanner.nextLine();

    return new Cliente(dni, sexo, email, nombre, new Localidad(0, "", 0));
    }*/
    
    private static void meterEnCola(List<Taquilla> taquillas, List<Cliente> clientes) {
    Scanner scanner = new Scanner(System.in);

    try {
        // Preguntar por el número de taquilla
        System.out.print("¿En qué taquilla deseas añadir a una persona? (1-" + taquillas.size() + "): ");
        int numTaquilla = scanner.nextInt();
        scanner.nextLine(); // Consumir salto de línea pendiente

        // Verificar si la taquilla existe
        int pos = buscarTaquilla((ArrayList<Taquilla>) taquillas, numTaquilla);
        if (pos == -1) {
            System.out.println("La taquilla no existe.");
            return;
        }

        // Preguntar por el código de cliente
        System.out.print("Código de cliente: ");
        int codCliente = scanner.nextInt();
        scanner.nextLine(); // Consumir salto de línea pendiente

        // Verificar si el cliente existe
        int posCli = buscarCodCli((ArrayList<Cliente>) clientes, codCliente);
        if (posCli == -1) {
            System.out.println("El cliente no existe.");
            return;
        }

        // Verificar si hay espacio en la cola
        Taquilla taquilla = taquillas.get(pos);
        if (taquilla.getColaClientes().size() >= taquilla.getPlazasMax()) {
            System.out.println("No hay sitio en esa cola.");
            return;
        }

        // Encolar al cliente
        taquilla.getColaClientes().add(clientes.get(posCli));
        System.out.println("Persona añadida a la cola exitosamente.");

    } catch (Exception e) {
        System.out.println("Error de entrada. Asegúrate de ingresar datos válidos.");
    } finally {
        scanner.nextLine(); // Limpiar el buffer del scanner
    }
}

    
    
    

    static void estadistica(ArrayList<Venta> ventas, ArrayList<Cliente> clientes) {
        int contH = 0;
        int contM = 0;
        int total = 0;
        int i = 0;

        while (i < ventas.size()) {
            int codCliente = ventas.get(i).getCodClientes();
            int cantidad = ventas.get(i).getCantidad();

            int posicion = buscar(clientes, codCliente);

            total += cantidad;

            if (posicion != -1) {
                if (clientes.get(posicion).getSexo() == 'M') {
                    contH += cantidad;
                } else {
                    contM += cantidad;
                }
            }

            i++;
        }

        if (total > 0) {
            System.out.println("Estadística por sexos:");
            System.out.println("Hombres = " + (contH * 100.0 / total) + "%");
            System.out.println("Mujeres = " + (contM * 100.0 / total) + "%");
        } else {
            System.out.println("No hay ventas para calcular estadísticas.");
        }
    }

    static int buscar(ArrayList<Cliente> clientes, int codCliente) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getCodClientes() == codCliente) {
                return i;
            }
        }
        return -1; // No encontrado
    }

    // Método para buscar un cliente por código
    static int buscarCodCli(ArrayList<Cliente> clientes, int codCliente) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getCodClientes() == codCliente) {
                return i;
            }
        }
        return -1; // No se encontró al cliente
    }
    
    static int buscarTaquilla(ArrayList<Taquilla> taquillas, int numTaquilla) {
    for (int i = 0; i < taquillas.size(); i++) {
        if (taquillas.get(i).getNumTaquilla() == numTaquilla) {
            return i;
        }
    }
    return -1; // No se encontró la taquilla
    }
    
    private static void actualizarDescuento(Cliente cliente, int numEntradas) {
        int posCli = buscar((ArrayList<Cliente>) clientes, cliente.getCodClientes());

        if (posCli != -1) {
            Cliente clienteActualizado = clientes.get(posCli);
            double nuevoDescuento = clienteActualizado.getDescuento() + (0.1 * numEntradas);
            clienteActualizado.setDescuento((float) nuevoDescuento);
        }
    }

    private static void actualizarEstadisticas(Cliente clienteAtendido) {
        if (clienteAtendido.getSexo() == 'M') {
            numHombres++;
        } else {
            numMujeres++;
        }
    }
    private static void atenderPersona(List<Taquilla> taquillas, List<Cliente> clientes, List<Venta> ventas) {
        Scanner scanner = new Scanner(System.in);

        int numTaquilla = solicitarNumero("Selecciona la taquilla (1-" + taquillas.size() + "): ");

        if (numTaquilla >= 1 && numTaquilla <= taquillas.size()) {
            Taquilla taquilla = taquillas.get(numTaquilla - 1);

            if (taquilla.getEmpleado() != null && !taquilla.getColaClientes().isEmpty()) {
                Cliente cliente = taquilla.getColaClientes().poll();
                System.out.println("Atendiendo a " + cliente.getNombre());

                // Solicitar el número de entradas y turno de la película
                int numEntradas = solicitarNumero("Número de entradas: ");
                if (numEntradas <= 0) {
                    System.out.println("El número de entradas debe ser mayor que cero.");
                    return;
                }

                int turnoPelicula = solicitarNumero("Turno de la película (1 - Sesión mañana, 2 - Sesión tarde): ");
                if (turnoPelicula != 1 && turnoPelicula != 2) {
                    System.out.println("Opción de turno no válida.");
                    return;
                }

                // Ajuste en el cálculo de la posición de la entrada
                int posEntrada = (turnoPelicula - 1) * 3 + 1;

                System.out.println("A pagar: " + taquilla.calcularPrecio(numEntradas, posEntrada, clientes) + "€");

                actualizarDescuento(cliente, numEntradas);

                String nickEmpleado = taquilla.getEmpleado().getNick();
                Venta nuevaVenta = new Venta(ventas.size() + 1, numEntradas, posEntrada, nickEmpleado, cliente.getCodClientes());
                ventas.add(nuevaVenta);

                actualizarEstadisticas(cliente);

                // Simulación de una transacción en un cine
                System.out.println("¡Transacción completada!");
                System.out.println("Cliente: " + cliente.getNombre());
                System.out.println("Número de entradas: " + numEntradas);
                System.out.println("Película: " + obtenerNombrePelicula(posEntrada)); // Método ficticio
                System.out.println("Precio total: " + taquilla.calcularPrecio(numEntradas, posEntrada, clientes));
                System.out.println("Disfruta de la película!");

            } else {
                System.out.println("La cola de la Taquilla " + numTaquilla + " está vacía o no hay empleado asignado.");
            }
        } else {
            System.out.println("Taquilla no válida.");
        }
    }

    // Método ficticio para obtener el nombre de la película
    private static String obtenerNombrePelicula(int posEntrada) {
        // Puedes implementar lógica para obtener el nombre de la película según la posición de la entrada
        // En este caso, se devuelve un nombre ficticio para el ejemplo.
        return "Pelicula Ejemplo";
    }
    
    private static int solicitarNumero(String mensaje) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        }
    }

}

