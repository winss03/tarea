/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

/**
 *
 * @author win_a
 */
public class Persona {
    String dni;
    private char sexo;
    private String email;
    private String nombre;
    private Localidad localidadPertenece;  // Nueva relación con Localidad

    // Constructor
    public Persona(String dni, char sexo, String email, String nombre, Localidad localidad) {
        this.dni = dni;
        this.sexo = sexo;
        this.email = email;
        this.nombre = nombre;
        this.localidadPertenece = localidad;
    }

    // Getter para dni
    public String getDni() {
        return dni;
    }

    // Setter para dni
    public void setDni(String dni) {
        this.dni = dni;
    }

    // Getter para sexo
    public char getSexo() {
        return sexo;
    }

    // Setter para sexo
    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    // Getter para email
    public String getEmail() {
        return email;
    }

    // Setter para email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter para nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Métodos adicionales según sea necesario
}

