/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

/**
 *
 * @author win_a
 */
import java.util.ArrayList;

public class Cine {
    private int codCine;
    private ArrayList<Taquilla> taquilla;

    // Constructor
    public Cine(int codCine, int numTaquillas, int plazasMaxPorTaquilla) {
        this.codCine = codCine;
        this.taquilla = new ArrayList<>();

        for (int i = 0; i < numTaquillas; i++) {
            taquilla.add(new Taquilla(i + 1, plazasMaxPorTaquilla));
        }
    }

    // Getter para codCine
    public int getCodCine() {
        return codCine;
    }

    // Setter para codCine
    public void setCodCine(int codCine) {
        this.codCine = codCine;
    }

    // Getter para taquilla
    public ArrayList<Taquilla> getTaquillas() {
        return taquilla;
    }

    // Setter para taquilla
    public void setTaquillas(ArrayList<Taquilla> taquillas) {
        this.taquilla = taquillas;
    }

    // Método adicional para mostrar estadísticas
    public void mostrarEstadisticas() {
        // Lógica para mostrar estadísticas (puedes implementar según sea necesario)
        System.out.println("Mostrar estadísticas aquí");
    }
}
