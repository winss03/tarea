/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;
import java.util.ArrayList;

/**
 *
 * @author win_a
 */


public class Localidad {
    private int codPostal;
    private String nombre;
    private int numHabitantes;
    private ArrayList<Cliente> localidades;  // Nuevo ArrayList de clientes en la localidad
    
    
    // Constructor
    public Localidad(int codPostal, String nombre, int numHabitantes) {
        this.codPostal = codPostal;
        this.nombre = nombre;
        this.numHabitantes = numHabitantes;
        this.localidades = new ArrayList<>();
    }
    
    // Getter y Setter para localidades
    public ArrayList<Cliente> getLocalidades() {
        return localidades;
    }

    public void setLocalidades(ArrayList<Cliente> localidades) {
        this.localidades = localidades;
    }

    // Método para agregar un cliente a la lista de localidades
    public void agregarClienteEnLocalidad(Cliente cliente) {
        localidades.add(cliente);
    }
    // Getter para codPostal
    public int getCodPostal() {
        return codPostal;
    }

    // Setter para codPostal
    public void setCodPostal(int codPostal) {
        this.codPostal = codPostal;
    }

    // Getter para nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para numHabitantes
    public int getNumHabitantes() {
        return numHabitantes;
    }

    // Setter para numHabitantes
    public void setNumHabitantes(int numHabitantes) {
        this.numHabitantes = numHabitantes;
    }

    // Métodos adicionales según sea necesario
}

