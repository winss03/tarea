/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

import java.util.ArrayList;

/**
 *
 * @author win_a
 */
public class Pelicula {
    private int codPeli;
    private float duracion;
    private String nombre;
    private String genero;
    private ArrayList<Pelicula> peliculas;
    

    // Constructor
    public Pelicula(int codPeli, float duracion, String nombre, String genero) {
        this.codPeli = codPeli;
        this.duracion = duracion;
        this.nombre = nombre;
        this.genero = genero;
        this.peliculas = new ArrayList<>();
    }
    // Getter y Setter para peliculas
    public ArrayList<Pelicula> getPeliculas() {
        return peliculas;
    }

    public void setPeliculas(ArrayList<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }

    // Getter para codPeli
    public int getCodPeli() {
        return codPeli;
    }

    // Setter para codPeli
    public void setCodPeli(int codPeli) {
        this.codPeli = codPeli;
    }

    // Getter para duracion
    public float getDuracion() {
        return duracion;
    }

    // Setter para duracion
    public void setDuracion(float duracion) {
        this.duracion = duracion;
    }

    // Getter para nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para genero
    public String getGenero() {
        return genero;
    }

    // Setter para genero
    public void setGenero(String genero) {
        this.genero = genero;
    }

    // Métodos adicionales según sea necesario
}

