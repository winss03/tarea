/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

/**
 *
 * @author win_a
 */
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Entrada implements Imprimible {
    private int numEntrada;
    private GregorianCalendar fecha;
    private float precio = 10;
    private Pelicula pelicula;
    private ArrayList<Entrada> entradas;
    

    // Constructor    
    public Entrada(int numEntrada, GregorianCalendar fecha, float precio, Pelicula p1) {
        this.numEntrada = numEntrada;
        this.fecha = fecha;
        this.precio = precio;
        this.pelicula = pelicula;
        this.entradas = new ArrayList<>();
    }
    
    // Getter y Setter para entradas
    public ArrayList<Entrada> getEntradas() {
        return entradas;
    }

    public void setEntradas(ArrayList<Entrada> entradas) {
        this.entradas = entradas;
    }
    
    //relación con la interfaz imprimible 
     @Override
    public void imprimirInformacion() {
        System.out.println("Información de la Entrada: Número " + numEntrada + ", Precio: " + precio);
        System.out.println("Pelicula: " + pelicula.getCodPeli()+ "nombre: " + pelicula.getNombre() + ", Duración: " + pelicula.getDuracion() + " minutos");
    }
  

    // Getter para numEntrada
    public int getNumEntrada() {
        return numEntrada;
    }

    // Setter para numEntrada
    public void setNumEntrada(int numEntrada) {
        this.numEntrada = numEntrada;
    }

    // Getter para fecha
    public GregorianCalendar getFecha() {
        return fecha;
    }

    // Setter para fecha
    public void setFecha(GregorianCalendar fecha) {
        this.fecha = fecha;
    }

    // Getter para precio
    public float getPrecio() {
        return precio;
    }

    // Setter para precio
    public void setPrecio(float precio) {
        this.precio = precio;
    }

    // Métodos adicionales según sea necesario
  
}
