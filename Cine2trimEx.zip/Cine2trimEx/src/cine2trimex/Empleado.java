/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

/**
 *
 * @author win_a
 */
import java.util.ArrayList;


public class Empleado extends Persona {
    private String nick;
    private String nombre;
    private int nivel;
    private ArrayList<Venta> ventasRealizadas;
    private ArrayList<Empleado> empleados;
    private ArrayList<Localidad> localidades;
    
    

    // Constructor
     public Empleado(String dni, char sexo, String email, String nombre, String nick, int nivel, Localidad localidad) {
        super(dni, sexo, email, nombre, localidad);
        this.nick = nick;
        this.nombre = nombre;
        this.nivel = nivel;
        this.ventasRealizadas = new ArrayList<>();
        this.empleados = new ArrayList<>(); 
    }

    // Método adicional para realizar una venta
    public void realizarVenta(Venta venta) {
        ventasRealizadas.add(venta);
        System.out.println("Venta realizada por " + nombre + ". Número de venta: " + venta.getNumVenta());
    }

    // Método adicional para mostrar las ventas realizadas por el empleado
    public void mostrarVentasRealizadas() {
        System.out.println("Ventas realizadas por " + nombre + ":");
        for (Venta venta : ventasRealizadas) {
            System.out.println("Número de venta: " + venta.getNumVenta() + ", Cantidad: " + venta.getCantidad());
        }
    }
    
    // Getter y Setter para empleados
    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    // Getter para nick
    public String getNick() {
        return nick;
    }

    // Setter para nick
    public void setNick(String nick) {
        this.nick = nick;
    }

    // Getter para nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para nivel
    public int getNivel() {
        return nivel;
    }

    // Setter para nivel
    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    // Métodos adicionales según sea necesario
}
