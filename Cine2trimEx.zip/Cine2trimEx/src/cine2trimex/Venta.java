/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

import java.util.ArrayList;

/**
 *
 * @author win_a
 */
public class Venta {
    private int numVenta;
    private int cantidad;
    private String nick;
    private int codCliente;
    private int numEntrada;
    private Empleado empleadoResponsable; //posible borrado
    private ArrayList<Venta> ventas;
    

    // Constructor
    public Venta(int numVenta, int cantidad, int empleadoResponsable, String nick1, int codClientes) {
        this.numVenta = numVenta;
        this.cantidad = cantidad;
        this.codCliente = codCliente;
        this.nick = nick;
        this.numEntrada= numEntrada;
        this.ventas = new ArrayList<>();
          
               

    }
    
     // Getter y Setter para ventas
    public ArrayList<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(ArrayList<Venta> ventas) {
        this.ventas = ventas;
    }

    // Getter para numVenta
    public int getNumVenta() {
        return numVenta;
    }

    // Setter para numVenta
    public void setNumVenta(int numVenta) {
        this.numVenta = numVenta;
    }

    // Getter para cantidad
    public int getCantidad() {
        return cantidad;
    }

    // Setter para cantidad
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    // Métodos adicionales según sea necesario

    int getCodClientes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

