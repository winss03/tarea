/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cine2trimex;

/**
 *
 * @author win_a
 */

import java.util.Queue;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.List;

public class Taquilla {
    public int numTaquilla;
    private Queue<Cliente> colaClientes;
    private int plazasMax;
    private String nick;
    private ArrayList<Cliente> clientesAtendidos;
    private Empleado empleado;

    // Constructor
    public Taquilla(int numTaquilla, int plazasMax) {
        this.numTaquilla = numTaquilla;
        this.colaClientes = new LinkedList<>();
        this.plazasMax = plazasMax;
        this.clientesAtendidos = new ArrayList<>();
        this.empleado = empleado;  // Inicialmente no hay empleado asignado
    }
    
    


        // Método adicional para asignar un empleado a la taquilla
    public void asignarEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }


    // Método adicional para mostrar información del empleado asignado
    public void mostrarInfoEmpleado() {
        if (empleado != null) {
            System.out.println("Empleado asignado a la Taquilla " + numTaquilla + ": " + empleado.getNick());
        } else {
            System.out.println("No hay empleado asignado a la Taquilla " + numTaquilla);
        }
    }
    
    // Método adicional para meter una persona en la cola
    public void meterPersonaEnCola(Cliente cliente) {
        if (colaClientes.size() < plazasMax) {
            colaClientes.add(cliente);
            System.out.println("Cliente " + cliente.getNombre() + " añadido a la cola de la Taquilla " + numTaquilla);
        } else {
            System.out.println("La cola de la Taquilla " + numTaquilla + " está llena.");
        }
    }

    // Método adicional para atender a una persona
    public void atenderPersona() {
        if (!colaClientes.isEmpty()) {
            Cliente cliente = colaClientes.poll();
            clientesAtendidos.add(cliente);  // Añadir cliente a la lista de clientes atendidos
            System.out.println("Atendiendo a " + cliente.getNombre());
            cliente.aumentarDescuento();
        } else {
            System.out.println("La cola de la Taquilla " + numTaquilla + " está vacía.");
        }
    }

    // Método adicional para mostrar información de los clientes atendidos
    public void mostrarClientesAtendidos() {
        System.out.println("Clientes atendidos en la Taquilla " + numTaquilla + ":");
        for (Cliente cliente : clientesAtendidos) {
            System.out.println("Nombre: " + cliente.getNombre() + ", Descuento: " + cliente.getDescuento());
        }
    }
    
    public Empleado getEmpleado() {
    return empleado;
    }
    

    // Getter para numTaquilla
    public int getNumTaquilla() {
        return numTaquilla;
    }

    // Setter para numTaquilla
    public void setNumTaquilla(int numTaquilla) {
        this.numTaquilla = numTaquilla;
    }

    // Getter para plazasMax
    public int getPlazasMax() {
        return plazasMax;
    }

    // Setter para plazasMax
    public void setPlazasMax(int plazasMax) {
        this.plazasMax = plazasMax;
    }

    // Getter para colaClientes
    public Queue<Cliente> getColaClientes() {
        return colaClientes;
    }

    // Setter para colaClientes (si es necesario)
    public void setColaClientes(Queue<Cliente> colaClientes) {
        this.colaClientes = colaClientes;
    }

    public String calcularPrecio(int numEntradas, int posEntrada, List<Cliente> clientes) {
        if (posEntrada >= 1 && posEntrada <= 6) {
            double precioBase = 10.0; // Precio base de la entrada
            double descuentoCliente = 0.0;

            // Obtener el descuento del cliente (suponiendo que se almacena en la lista de clientes)
            Cliente cliente = clientes.get(posEntrada - 1); // Ajuste en la posición
            descuentoCliente = cliente.getDescuento();

            // Calcular el precio con descuento
            double precioFinal = precioBase - (precioBase * descuentoCliente);

            // Aplicar descuento por cantidad de entradas
             if (numEntradas > 1) {
              precioFinal = precioFinal * 0.9; // Aplicar descuento del 10% por cada entrada adicional
            }

            // Formatear el precio con dos decimales y el símbolo €
            String precioFormateado = String.format("%.2f €", precioFinal);

            return "Precio por " + numEntradas + " entradas en posición " + posEntrada + ": " + precioFormateado;
        } else {
            return "Posición de entrada no válida.";
        }
    }


}

